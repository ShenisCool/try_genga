clear
make
./genga
