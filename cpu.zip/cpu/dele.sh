python3 dele.py
clear
