bash delet.sh
./gengaCPU
./KE -pmin 0 -pmax 2048000 -in test
